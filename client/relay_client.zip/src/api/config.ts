// =============================================================================
// API Configuration
// =============================================================================
// Toggle USE_MOCK to false when real backend is ready.
// Services check this flag and route to real fetch calls or mock data.
// =============================================================================

export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api',
  USE_MOCK: false,
  MOCK_DELAY_MIN: 300,
  MOCK_DELAY_MAX: 800,
} as const;

/** Simulate network latency for mock data */
export function simulateDelay(): Promise<void> {
  const ms =
    Math.random() * (API_CONFIG.MOCK_DELAY_MAX - API_CONFIG.MOCK_DELAY_MIN) +
    API_CONFIG.MOCK_DELAY_MIN;
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Optionally simulate a random error (for testing error states) */
export function maybeThrowMockError(rate = 0.03): void {
  if (Math.random() < rate) {
    throw {
      message: 'Simulated network error',
      code: 'MOCK_ERROR',
      statusCode: 500,
    };
  }
}
