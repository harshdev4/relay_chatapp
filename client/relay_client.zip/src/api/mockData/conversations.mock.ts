// =============================================================================
// Mock Conversations Data
// =============================================================================
import type { Conversation } from '../../types/types';
import { CURRENT_USER_ID, otherUsers } from './users.mock';
import { mockMessages } from './messages.mock';

function buildConversations(): Conversation[] {
  const unreadCounts = [3, 0, 5, 0, 1, 0, 12, 0, 2, 99, 0, 0, 7];

  return otherUsers.map((user, index) => {
    const convoId = `conv-${user.id}`;
    const messages = mockMessages[convoId] || [];
    const lastMsg = messages.length > 0 ? messages[messages.length - 1] : null;

    return {
      id: convoId,
      participantIds: [CURRENT_USER_ID, user.id],
      lastMessage: lastMsg,
      unreadCount: unreadCounts[index % unreadCounts.length],
      updatedAt: lastMsg
        ? lastMsg.createdAt
        : new Date(Date.now() - (index + 1) * 86400000).toISOString(),
    };
  });
}

export const mockConversations: Conversation[] = buildConversations().sort(
  (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
);
