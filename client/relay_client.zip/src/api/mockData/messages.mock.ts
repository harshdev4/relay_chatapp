// =============================================================================
// Mock Messages Data
// =============================================================================
import type { Message } from '../../types/types';
import { CURRENT_USER_ID, otherUsers } from './users.mock';

/** Generate a deterministic set of messages for each conversation */
function generateMessages(
  conversationId: string,
  otherUserId: string,
  count: number,
  baseDaysAgo: number
): Message[] {
  const messages: Message[] = [];
  const conversationTexts: Record<string, string[][]> = {
    default: [
      ['Hey, how are you doing?', 'I\'m doing great, thanks for asking! 😊'],
      ['Did you check out that new feature?', 'Yes! It looks amazing. The animations are super smooth.'],
      ['Want to grab lunch tomorrow?', 'Sure! How about that new Thai place?'],
      ['The deployment went well', 'Awesome, glad to hear it! No issues at all?'],
      ['Can you review my PR when you get a chance?', 'On it! I\'ll take a look this afternoon.'],
      ['Happy Friday! 🎉', 'Happy Friday! Any plans for the weekend?'],
      ['The meeting got moved to 3pm', 'Thanks for the heads up!'],
      ['Just pushed the fix for that bug', 'Nice work! That was a tricky one.'],
      ['Have you tried the new dark mode?', 'Not yet, but I heard it looks great!'],
      ['The client loved the demo!', 'That\'s incredible news! All that hard work paid off.'],
      ['Running a bit late today', 'No worries, take your time 👍'],
      ['Check your email - sent the design specs', 'Got them! These look really clean.'],
      ['We should refactor the auth module', 'Agreed. I\'ve been thinking about that too.'],
      ['The test coverage is up to 87% now', 'Wow, that\'s a huge improvement! Great job.'],
      ['Do you have the Figma link?', 'Here you go: figma.com/file/...'],
      ['Sprint retro at 4?', 'Yep, already on my calendar.'],
      ['The API response times improved by 40%!', 'That caching strategy really paid off!'],
      ['Can we pair program on this?', 'Absolutely! I\'ll set up a call.'],
      ['Just submitted my talk proposal 🎤', 'That\'s exciting! What\'s the topic?'],
      ['The CI pipeline is green again ✅', 'Finally! What was the issue?'],
    ],
  };

  const texts = conversationTexts.default;
  const now = Date.now();

  const totalWindowMs = Math.max(baseDaysAgo, 0) * 24 * 60 * 60 * 1000;

  // Space pairs evenly across the window, with a minimum spacing
  // (so a 0-day conversation still has messages a few minutes apart,
  // never in the future).
  const minSpacingMs = 5 * 60 * 1000; // 5 minutes
  const spacingMs = count > 1
    ? Math.max(totalWindowMs / (count - 1), minSpacingMs)
    : 0;

  for (let i = 0; i < count; i++) {
    const pair = texts[i % texts.length];
    const timeOffset = totalWindowMs - i * spacingMs;
    const safeOffset = Math.max(timeOffset, 0);
    const isSent = i % 2 === 0;

    // "Sent" message from current user
    messages.push({
      id: `msg-${conversationId}-${i * 2}`,
      conversationId,
      senderId: isSent ? CURRENT_USER_ID : otherUserId,
      text: pair[0],
      createdAt: new Date(now - safeOffset).toISOString(),
      status: 'read',
    });

    // "Received" reply
    messages.push({
      id: `msg-${conversationId}-${i * 2 + 1}`,
      conversationId,
      senderId: isSent ? otherUserId : CURRENT_USER_ID,
      text: pair[1],
      createdAt: new Date(now - safeOffset + 3 * 60 * 1000).toISOString(),
      status: 'read',
    });
  }

  // Sort chronologically
  messages.sort(
    (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  return messages;
}

// Build message map keyed by conversationId
const messageCounts = [10, 8, 12, 6, 15, 5, 9, 7, 11, 20, 8, 6, 14];
const baseDaysAgo =   [1,  3,  0,  7,  0,  14, 2,  5,  1,  0,  4,  10, 0 ];

export const mockMessages: Record<string, Message[]> = {};

otherUsers.forEach((user, index) => {
  const convoId = `conv-${user.id}`;
  const count = messageCounts[index % messageCounts.length];
  const days = baseDaysAgo[index % baseDaysAgo.length];
  mockMessages[convoId] = generateMessages(convoId, user.id, count, days);
});

// Edge case: one conversation with a very long message
const longMsgConvoId = 'conv-user-4';
if (mockMessages[longMsgConvoId] && mockMessages[longMsgConvoId].length > 2) {
  mockMessages[longMsgConvoId][2] = {
    ...mockMessages[longMsgConvoId][2],
    text: 'This is an intentionally very long message to test how the UI handles edge cases. '.repeat(8) +
      'It should wrap nicely and not break the layout. The message bubble should expand to accommodate this text while still looking great. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
  };
}

// Edge case: conv-user-11 has NO messages (empty conversation)
mockMessages['conv-user-11'] = [];
