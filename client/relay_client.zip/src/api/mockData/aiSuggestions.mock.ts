// =============================================================================
// Mock AI Suggestions Data
// =============================================================================
import type { AISuggestion } from '../../types/types';

/** Canned suggestion templates — keyed by tone */
const suggestionTemplates: Record<string, (text: string) => string> = {
  formal: (text: string) => {
    const words = text.trim().split(/\s+/);
    if (words.length < 2) return `I would like to inform you that ${text.toLowerCase()}`;
    return `I wanted to follow up regarding ${text.toLowerCase()}. Please let me know your thoughts at your earliest convenience.`;
  },
  casual: (text: string) => {
    const words = text.trim().split(/\s+/);
    if (words.length < 2) return `hey! ${text} 😄`;
    return `hey, ${text.toLowerCase()} — let me know what you think! 🙌`;
  },
  concise: (text: string) => {
    const words = text.trim().split(/\s+/);
    if (words.length <= 3) return text;
    // Take first few meaningful words
    return words.slice(0, Math.ceil(words.length * 0.6)).join(' ') + '.';
  },
  friendly: (text: string) => {
    return `Hope you're doing well! ${text} 😊 Looking forward to hearing from you!`;
  },
};

let suggestionCounter = 0;

/** Generate mock AI suggestions for a given draft text */
export function generateMockSuggestions(draftText: string): AISuggestion[] {
  if (!draftText || draftText.trim().length < 3) return [];

  const tones: Array<'formal' | 'casual' | 'concise' | 'friendly'> = [
    'formal',
    'casual',
    'concise',
  ];

  // Occasionally include a 4th "friendly" suggestion
  if (Math.random() > 0.5) {
    tones.push('friendly');
  }

  return tones.slice(0, 3).map((tone) => ({
    id: `suggestion-${++suggestionCounter}`,
    text: suggestionTemplates[tone](draftText),
    tone,
  }));
}
