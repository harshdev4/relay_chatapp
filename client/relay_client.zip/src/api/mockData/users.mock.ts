// =============================================================================
// Mock Users Data
// =============================================================================
import type { User } from '../../types/types';

export const CURRENT_USER_ID = 'user-me';

export const currentUser: User = {
  id: CURRENT_USER_ID,
  name: 'Alex Morgan',
  email: 'harshtiwari6458@gmail.com',
  avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Alex',
  status: 'online',
  lastSeen: new Date().toISOString(),
  bio: 'Building the future of communication ✨',
};

export const mockUsers: User[] = [
  currentUser,
  {
    id: 'user-1',
    name: 'Sarah Chen',
    email: 'sarah@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Sarah',
    status: 'online',
    lastSeen: new Date().toISOString(),
    bio: 'Product designer & coffee enthusiast',
  },
  {
    id: 'user-2',
    name: 'Marcus Johnson',
    email: 'marcus@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Marcus',
    status: 'online',
    lastSeen: new Date().toISOString(),
    bio: 'Full-stack developer',
  },
  {
    id: 'user-3',
    name: 'Priya Patel',
    email: 'priya@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Priya',
    status: 'away',
    lastSeen: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    bio: 'Data scientist | ML researcher',
  },
  {
    id: 'user-4',
    name: 'James Williams',
    email: 'james@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=James',
    status: 'offline',
    lastSeen: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    bio: 'Engineering manager',
  },
  {
    id: 'user-5',
    name: 'Luna Kim',
    email: 'luna@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Luna',
    status: 'online',
    lastSeen: new Date().toISOString(),
    bio: 'UX researcher & accessibility advocate',
  },
  {
    id: 'user-6',
    name: 'Omar Hassan',
    email: 'omar@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Omar',
    status: 'offline',
    lastSeen: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    bio: 'DevOps engineer',
  },
  {
    id: 'user-7',
    name: 'Emma Davis',
    email: 'emma@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Emma',
    status: 'online',
    lastSeen: new Date().toISOString(),
  },
  {
    id: 'user-8',
    name: 'Rafael Torres',
    email: 'rafael@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Rafael',
    status: 'away',
    lastSeen: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    bio: 'Mobile developer | React Native',
  },
  {
    id: 'user-9',
    name: 'Aisha Nakamura',
    email: 'aisha@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Aisha',
    status: 'offline',
    lastSeen: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    bio: 'Backend architect',
  },
  {
    id: 'user-10',
    name: 'Liam O\'Brien',
    email: 'liam@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Liam',
    status: 'online',
    lastSeen: new Date().toISOString(),
    bio: 'Security specialist 🔒',
  },
  {
    id: 'user-11',
    name: 'Yuki Tanaka',
    email: 'yuki@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Yuki',
    status: 'offline',
    lastSeen: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    bio: 'QA lead',
  },
  {
    id: 'user-12',
    name: 'Sofia Rodriguez',
    email: 'sofia@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=Sofia',
    status: 'online',
    lastSeen: new Date().toISOString(),
    bio: 'Technical writer & documentation nerd 📝',
  },
  {
    id: 'user-13',
    name: 'David Park',
    email: 'david@example.com',
    avatarUrl: 'https://api.dicebear.com/9.x/adventurer/svg?seed=David',
    status: 'away',
    lastSeen: new Date(Date.now() - 10 * 60 * 1000).toISOString(),
  },
];

/** Get other users (excluding the current user) */
export const otherUsers = mockUsers.filter((u) => u.id !== CURRENT_USER_ID);
