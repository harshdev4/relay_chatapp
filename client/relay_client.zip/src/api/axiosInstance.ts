import axios from "axios";
import { API_CONFIG } from "./config";

export const axiosInstance = axios.create({
    baseURL: API_CONFIG.BASE_URL,
    withCredentials: true,

})