// =============================================================================
// Conversation Service
// =============================================================================
import type { Conversation } from '../../types/types';
import { axiosInstance } from '../axiosInstance';

export async function getConversations(): Promise<Conversation[]> {
  const res = await axiosInstance.get(`/conversations`);
  return res.data as Promise<Conversation[]>;
}

export async function getConversationById(id: string): Promise<Conversation> {
  const res = await axiosInstance.get(`/conversations/${id}`);
  return res.data as Promise<Conversation>;
}
