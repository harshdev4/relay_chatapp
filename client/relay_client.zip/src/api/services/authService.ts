// =============================================================================
// Auth Service
// =============================================================================
import type { ApiError, AuthPayload, LoginRequest, SignupRequest } from '../../types/types';
import { axiosInstance } from '../axiosInstance';
import { API_CONFIG, simulateDelay } from '../config';
import { currentUser, mockUsers } from '../mockData/users.mock';

export async function login(req: LoginRequest): Promise<AuthPayload> {
  if (API_CONFIG.USE_MOCK) {
    await simulateDelay();

    // Simple mock validation
    const user = mockUsers.find((u) => u.email === req.email);
    if (!user || req.password.length < 4) {
      const error : ApiError = {
        message: 'Invalid email or password',
      };
      throw error;
    }

    return {
      user,
      token: `mock-token-${Date.now()}`,
    };
  }

  const res = await axiosInstance.post<AuthPayload>(`/auth/login`, req);
  return res.data;
}

export async function signup(req: SignupRequest): Promise<AuthPayload> {
  if (API_CONFIG.USE_MOCK) {
    await simulateDelay();

    // Mock: check if email already exists
    if (mockUsers.some((u) => u.email === req.email)) {
      const error : ApiError = {
        message: 'An account with this email already exists',
      };

      throw error;
    }

    const newUser = {
      ...currentUser,
      id: `user-${Date.now()}`,
      name: req.name,
      email: req.email,
      avatarUrl: `https://api.dicebear.com/9.x/adventurer/svg?seed=${encodeURIComponent(req.name)}`,
    };

    return {
      user: newUser,
      token: `mock-token-${Date.now()}`,
    };
  }

  
  const res = await axiosInstance.post<AuthPayload>(`/auth/signup`, req);
  return res.data;
}


export async function logout(): Promise<void> {
  if (API_CONFIG.USE_MOCK) {
    await simulateDelay();
    return;
  }

  await axiosInstance.post<void>(`/auth/logout`);
}


export async function getSession(): Promise<AuthPayload | null> {
  if (API_CONFIG.USE_MOCK) {
    await simulateDelay();
    return null;
  }

  const res = await axiosInstance.get<AuthPayload>(`/auth/session`)
  return res.data;
}
