// =============================================================================
// AI Service
// =============================================================================
import type { AISuggestionRequest, AISuggestionResponse } from '../../types/types';
import { axiosInstance } from '../axiosInstance';


// TODO(backend): replace mock with:
// POST /api/ai/suggestions  AISuggestionRequest -> AISuggestionResponse
export async function getSuggestions(
  req: AISuggestionRequest
): Promise<AISuggestionResponse> {

  const res = await axiosInstance.post(`/ai/suggestions`, req);
  return res.data as Promise<AISuggestionResponse>;
}
