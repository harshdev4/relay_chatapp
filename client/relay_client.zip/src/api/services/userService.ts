// =============================================================================
// User Service
// =============================================================================
import type { User, AvatarUpdateRequest } from '../../types/types';
import { axiosInstance } from '../axiosInstance';

export async function getUsers(): Promise<User[]> {
  const res = await axiosInstance.get(`/users`);
  return res.data as Promise<User[]>;
}

export async function getUserById(id: string): Promise<User> {
  const res = await axiosInstance.get(`/users/${id}`);
  return res.data as Promise<User>;
}


export async function updateProfile(
  id: string,
  updates: Partial<User>
): Promise<User> {

  const res = await axiosInstance.patch(`/users/${id}`, updates);
  return res.data as Promise<User>;
}


export async function updateAvatar(
  req: AvatarUpdateRequest
): Promise<{ avatarUrl: string }> {

  const formData = new FormData();
  formData.append('file', req.file);
  const res = await axiosInstance.post(`/users/${req.userId}/avatar`, formData);
  return res.data;
}
