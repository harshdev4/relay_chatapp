// =============================================================================
// Mock Socket — Socket.IO-like interface
// =============================================================================
// Simulates real-time events (new messages, typing indicators, presence changes)
// using setInterval/setTimeout. Exposes a Socket.IO-compatible API so swapping
// in a real socket.io-client later requires changing only this file.
// =============================================================================
import type { Message, TypingEvent, PresenceEvent, PresenceStatus } from '../types/types';
import { mockConversations } from './mockData/conversations.mock';
import { otherUsers, CURRENT_USER_ID } from './mockData/users.mock';
import { mockMessages } from './mockData/messages.mock';

type EventMap = {
  'message:new': Message;
  'typing:update': TypingEvent;
  'presence:update': PresenceEvent;
};

type EventName = keyof EventMap;
type Callback<T> = (data: T) => void;

interface MockSocketInstance {
  connect: () => void;
  disconnect: () => void;
  on: <E extends EventName>(event: E, callback: Callback<EventMap[E]>) => void;
  off: <E extends EventName>(event: E, callback: Callback<EventMap[E]>) => void;
  emit: <E extends EventName>(event: E, data: EventMap[E]) => void;
  connected: boolean;
}

const incomingMessageTexts = [
  'Hey, are you around?',
  'Just checking in on that project 👋',
  'Have you seen the latest updates?',
  'Quick question about the API...',
  'The design looks great!',
  'Can we sync up later today?',
  'Pushed some new changes to the repo',
  'Thanks for the feedback! Working on it now.',
  'Do you have 5 minutes for a quick call?',
  'Just finished the code review ✅',
  'The tests are passing now!',
  'What do you think about this approach?',
  'Let me know when you\'re free',
  'Great progress on the feature! 🚀',
];

function createMockSocket(): MockSocketInstance {
  const listeners: { [K in EventName]: Set<Callback<EventMap[K]>> } = {
    'message:new': new Set(),
    'typing:update': new Set(),
    'presence:update': new Set(),
  };

  const intervals: number[] = [];
  const timeouts: number[] = [];
  let isConnected = false;

  function emit<E extends EventName>(event: E, data: EventMap[E]) {
    listeners[event]?.forEach((cb) => cb(data));
  }

  function startSimulations() {
    // ── Simulate incoming messages every 15-30s ──
    const msgInterval = window.setInterval(() => {
      if (!isConnected) return;

      const randomUser =
        otherUsers[Math.floor(Math.random() * otherUsers.length)];
      const convoId = `conv-${randomUser.id}`;
      const text =
        incomingMessageTexts[
          Math.floor(Math.random() * incomingMessageTexts.length)
        ];

      // Show typing first
      emit('typing:update', {
        conversationId: convoId,
        userId: randomUser.id,
        isTyping: true,
      });

      // Then send message after 1-3 seconds
      const typingDuration = 1000 + Math.random() * 2000;
      const t = window.setTimeout(() => {
        if (!isConnected) return;

        emit('typing:update', {
          conversationId: convoId,
          userId: randomUser.id,
          isTyping: false,
        });

        const newMsg: Message = {
          id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          conversationId: convoId,
          senderId: randomUser.id,
          text,
          createdAt: new Date().toISOString(),
          status: 'delivered',
        };

        // Add to mock data store
        if (!mockMessages[convoId]) {
          mockMessages[convoId] = [];
        }
        mockMessages[convoId].push(newMsg);

        const conversation = mockConversations.find((item) => item.id === convoId);
        if (conversation) {
          conversation.lastMessage = newMsg;
          conversation.updatedAt = newMsg.createdAt;
          conversation.unreadCount += 1;
        }

        emit('message:new', newMsg);
      }, typingDuration);
      timeouts.push(t);
    }, 15000 + Math.random() * 15000);
    intervals.push(msgInterval);

    // ── Simulate presence changes every 10-25s ──
    const presenceInterval = window.setInterval(() => {
      if (!isConnected) return;

      const randomUser =
        otherUsers[Math.floor(Math.random() * otherUsers.length)];
      const statuses: PresenceStatus[] = ['online', 'offline', 'away'];
      const newStatus =
        statuses[Math.floor(Math.random() * statuses.length)];

      // Update mock user data
      randomUser.status = newStatus;
      randomUser.lastSeen = new Date().toISOString();

      emit('presence:update', {
        userId: randomUser.id,
        status: newStatus,
      });
    }, 10000 + Math.random() * 15000);
    intervals.push(presenceInterval);
  }

  return {
    get connected() {
      return isConnected;
    },

    connect() {
      if (isConnected) return;
      isConnected = true;
      startSimulations();
    },

    disconnect() {
      isConnected = false;
      intervals.forEach((id) => clearInterval(id));
      timeouts.forEach((id) => clearTimeout(id));
      intervals.length = 0;
      timeouts.length = 0;
    },

    on<E extends EventName>(event: E, callback: Callback<EventMap[E]>) {
      listeners[event]?.add(callback);
    },

    off<E extends EventName>(event: E, callback: Callback<EventMap[E]>) {
      listeners[event]?.delete(callback);
    },

    emit<E extends EventName>(event: E, data: EventMap[E]) {
      // For client-emitted events (e.g., typing indicator from current user)
      // In real implementation, this would send to server
      // For mock, we just handle it locally
      if (event === 'typing:update') {
        const typingData = data as TypingEvent;
        typingData.userId = CURRENT_USER_ID;
        // No need to broadcast back to self in mock mode
      }
    },
  };
}

// Singleton instance
export const mockSocket = createMockSocket();
