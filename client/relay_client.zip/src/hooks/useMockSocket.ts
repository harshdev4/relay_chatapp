// =============================================================================
// Mock Socket Hook
// =============================================================================
// Connects to the mock socket on mount, dispatches events to Zustand stores
// and React Query cache.
// =============================================================================
import { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { mockSocket } from '../api/mockSocket';
import { useChatStore } from '../store/useChatStore';
import { queryKeys } from '../api/queryKeys';
import type { Message, TypingEvent } from '../types/types';

export function useMockSocket() {
  const queryClient = useQueryClient();
  const incrementUnread = useChatStore((s) => s.incrementUnread);
  const activeConversationId = useChatStore((s) => s.activeConversationId);
  const setTyping = useChatStore((s) => s.setTyping);

  useEffect(() => {
    mockSocket.connect();

    const handleNewMessage = (msg: Message) => {
      // Invalidate message list for that conversation
      queryClient.invalidateQueries({
        queryKey: queryKeys.messages.byConversation(msg.conversationId),
      });
      // Invalidate conversation list (to update lastMessage & ordering)
      queryClient.invalidateQueries({
        queryKey: queryKeys.conversations.all,
      });

      // Increment unread if this isn't the active conversation
      if (msg.conversationId !== activeConversationId) {
        incrementUnread(msg.conversationId);
      }
    };

    const handleTyping = (event: TypingEvent) => {
      setTyping(event.conversationId, event.isTyping);
    };

    const handlePresence = () => {
      // Invalidate users query to reflect new presence status
      queryClient.invalidateQueries({
        queryKey: queryKeys.users.all,
      });
    };

    mockSocket.on('message:new', handleNewMessage);
    mockSocket.on('typing:update', handleTyping);
    mockSocket.on('presence:update', handlePresence);

    return () => {
      mockSocket.off('message:new', handleNewMessage);
      mockSocket.off('typing:update', handleTyping);
      mockSocket.off('presence:update', handlePresence);
      mockSocket.disconnect();
    };
  }, [queryClient, incrementUnread, activeConversationId, setTyping]);
}
