import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, LayoutGroup, motion } from 'framer-motion';
import {
  Bot,
  Menu,
  MessageCircle,
  Moon,
  Search,
  Send,
  Settings,
  Sparkles,
  Sun,
  X,
} from 'lucide-react';
import { useMockSocket } from '../hooks/useMockSocket';
import {
  useAISuggestions,
  useConversations,
  useMarkAsRead,
  useMessages,
  useSendMessage,
  useUsers,
} from '../hooks/useQueryHooks';
import { useAuthStore } from '../store/useAuthStore';
import { useChatStore } from '../store/useChatStore';
import { useThemeStore } from '../store/useThemeStore';
import { useUIStore } from '../store/useUIStore';
import type { Conversation, Message, PresenceStatus, User } from '../types/types';
import styles from './ChatPage.module.css';

const EMPTY_CONVERSATIONS: Conversation[] = [];
const EMPTY_USERS: User[] = [];
const EMPTY_MESSAGES: Message[] = [];

function formatTime(value: string) {
  const date = new Date(value);
  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();
  return isToday
    ? date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
    : date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

function statusClass(status: PresenceStatus) {
  if (status === 'online') return styles.statusOnline;
  if (status === 'away') return styles.statusAway;
  return styles.statusOffline;
}

function getOtherUser(conversation: Conversation, users: User[], currentUserId?: string) {
  const otherId = conversation.participantIds.find((id) => id !== currentUserId);
  return users.find((user) => user.id === otherId);
}

export default function ChatPage() {
  useMockSocket();

  const user = useAuthStore((s) => s.user);
  const activeConversationId = useChatStore((s) => s.activeConversationId);
  const setActiveConversation = useChatStore((s) => s.setActiveConversation);
  const setUnreadCounts = useChatStore((s) => s.setUnreadCounts);
  const unreadCounts = useChatStore((s) => s.unreadCounts);
  const typingUsers = useChatStore((s) => s.typingUsers);
  const mobileSidebarOpen = useUIStore((s) => s.mobileSidebarOpen);
  const setMobileSidebarOpen = useUIStore((s) => s.setMobileSidebarOpen);
  const toggleMode = useThemeStore((s) => s.toggleMode);
  const mode = useThemeStore((s) => s.mode);

  const conversationsQuery = useConversations();
  const usersQuery = useUsers();
  const messagesQuery = useMessages(activeConversationId);
  const sendMessage = useSendMessage();
  const { mutate: markConversationAsRead } = useMarkAsRead();
  const aiSuggestions = useAISuggestions();

  const [search, setSearch] = useState('');
  const [draft, setDraft] = useState('');
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const conversations = conversationsQuery.data ?? EMPTY_CONVERSATIONS;
  const users = usersQuery.data ?? EMPTY_USERS;
  const messages = messagesQuery.data?.items ?? EMPTY_MESSAGES;
  const activeConversation = conversations.find((item) => item.id === activeConversationId);
  const activeUser = activeConversation
    ? getOtherUser(activeConversation, users, user?.id)
    : undefined;
  const isTyping = activeConversationId ? typingUsers[activeConversationId] : false;

  useEffect(() => {
    if (!conversations.length) return;
    const counts = Object.fromEntries(
      conversations.map((conversation) => [conversation.id, conversation.unreadCount])
    );
    setUnreadCounts(counts);
  }, [conversations, setUnreadCounts]);

  useEffect(() => {
    if (!activeConversationId) return;
    markConversationAsRead(activeConversationId);
  }, [activeConversationId, markConversationAsRead]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages.length, isTyping]);

  const searchTerm = search.trim().toLowerCase();
  const sidebarItems = conversations
    .map((conversation) => ({
      conversation,
      otherUser: getOtherUser(conversation, users, user?.id),
      unreadCount: unreadCounts[conversation.id] ?? conversation.unreadCount,
    }))
    .filter(({ otherUser }) => otherUser?.name.toLowerCase().includes(searchTerm))
    .sort((a, b) => {
      return (
        new Date(b.conversation.updatedAt).getTime() -
        new Date(a.conversation.updatedAt).getTime()
      );
    });

  function handleSelect(conversationId: string) {
    setActiveConversation(conversationId);
    setMobileSidebarOpen(false);
  }

  function handleSuggest() {
    const trimmed = draft.trim();
    if (!trimmed || !activeConversationId) return;
    aiSuggestions.mutate({ conversationId: activeConversationId, draftText: trimmed });
  }

  function handleSend() {
    const trimmed = draft.trim();
    if (!trimmed || !activeConversationId) return;
    sendMessage.mutate(
      { conversationId: activeConversationId, text: trimmed },
      {
        onSuccess: () => {
          setDraft('');
          aiSuggestions.reset();
        },
      }
    );
  }

  function handleKeyDown(event: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      handleSend();
    }
  }

  return (
    <div className={styles.layout}>
      <button
        className={`${styles.mobileOverlay} ${
          mobileSidebarOpen ? styles.mobileOverlayVisible : ''
        }`}
        aria-label="Close conversation list"
        onClick={() => setMobileSidebarOpen(false)}
      />

      <aside className={`${styles.sidebar} ${mobileSidebarOpen ? styles.sidebarOpen : ''}`}>
        <div className={styles.sidebarHeader}>
          <div className={styles.sidebarTopRow}>
            <div className={styles.sidebarTitle}>
              <MessageCircle size={20} />
              Relay
            </div>
            <div className={styles.sidebarActions}>
              <button className={styles.iconBtn} type="button" onClick={toggleMode} aria-label="Toggle theme mode">
                {mode === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
              </button>
              <Link className={styles.iconBtn} to="/settings" aria-label="Open settings">
                <Settings size={18} />
              </Link>
              <button
                className={`${styles.iconBtn} ${styles.mobileMenuBtn}`}
                type="button"
                onClick={() => setMobileSidebarOpen(false)}
                aria-label="Close sidebar"
              >
                <X size={18} />
              </button>
            </div>
          </div>
          <div className={styles.searchWrapper}>
            <Search className={styles.searchIcon} />
            <input
              className={styles.searchInput}
              placeholder="Search conversations"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </div>
        </div>

        <LayoutGroup>
          <div className={styles.conversationList}>
            {sidebarItems.map(({ conversation, otherUser, unreadCount }) => {
              if (!otherUser) return null;
              const active = conversation.id === activeConversationId;
              const typing = typingUsers[conversation.id];
              return (
                <motion.button
                  layout
                  key={conversation.id}
                  type="button"
                  className={`${styles.conversationItem} ${
                    active ? styles.conversationItemActive : ''
                  } ${unreadCount > 0 && !active ? styles.conversationItemUnread : ''}`}
                  onClick={() => handleSelect(conversation.id)}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className={styles.avatarWrapper}>
                    <img className={styles.avatar} src={otherUser.avatarUrl} alt="" />
                    <span className={`${styles.statusDot} ${statusClass(otherUser.status)}`} />
                  </div>
                  <div className={styles.convInfo}>
                    <div className={styles.convTopRow}>
                      <span className={styles.convName}>{otherUser.name}</span>
                      <span className={styles.convTime}>{formatTime(conversation.updatedAt)}</span>
                    </div>
                    <div className={styles.convBottomRow}>
                      <span className={`${styles.convPreview} ${typing ? styles.convTyping : ''}`}>
                        {typing
                          ? 'typing...'
                          : conversation.lastMessage?.text || 'No messages yet'}
                      </span>
                      {unreadCount > 0 && !active && (
                        <span className={styles.unreadBadge}>
                          {unreadCount > 99 ? '99+' : unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </LayoutGroup>
      </aside>

      <main className={styles.mainContent}>
        {!activeConversation || !activeUser ? (
          <div className={styles.emptyState}>
            <Bot className={styles.emptyIcon} />
            <h1 className={styles.emptyTitle}>Select a chat to start messaging</h1>
            <p className={styles.emptySubtext}>Your conversations and AI suggestions are ready when you are.</p>
          </div>
        ) : (
          <>
            <header className={styles.chatHeader}>
              <button
                className={`${styles.iconBtn} ${styles.mobileMenuBtn}`}
                type="button"
                onClick={() => setMobileSidebarOpen(true)}
                aria-label="Open conversation list"
              >
                <Menu size={20} />
              </button>
              <div className={styles.avatarWrapper}>
                <img className={styles.avatar} src={activeUser.avatarUrl} alt="" />
                <span className={`${styles.statusDot} ${statusClass(activeUser.status)}`} />
              </div>
              <div className={styles.chatHeaderInfo}>
                <h1 className={styles.chatHeaderName}>{activeUser.name}</h1>
                <div className={styles.chatHeaderStatus}>
                  <span className={`${styles.statusDotSmall} ${statusClass(activeUser.status)}`} />
                  {isTyping ? 'typing...' : activeUser.status}
                </div>
              </div>
            </header>

            <section className={styles.messageArea} aria-live="polite">
              <AnimatePresence initial={false}>
                {messages.map((message: Message) => {
                  const sent = message.senderId === user?.id;
                  return (
                    <motion.div
                      key={message.id}
                      className={`${styles.messageRow} ${
                        sent ? styles.messageRowSent : styles.messageRowReceived
                      }`}
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                    >
                      <div className={`${styles.messageBubble} ${sent ? styles.bubbleSent : styles.bubbleReceived}`}>
                        {message.text}
                        <div className={styles.messageTime}>{formatTime(message.createdAt)}</div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
              {isTyping && (
                <div className={styles.typingIndicator}>
                  <div className={styles.typingDots}>
                    <span className={styles.typingDot} />
                    <span className={styles.typingDot} />
                    <span className={styles.typingDot} />
                  </div>
                  <span className={styles.typingText}>{activeUser.name} is typing</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </section>

            <footer className={styles.inputArea}>
              {aiSuggestions.isPending && (
                <div className={styles.suggestionsLoading}>
                  <span className={styles.suggestionSkeleton} style={{ width: 160 }} />
                  <span className={styles.suggestionSkeleton} style={{ width: 220 }} />
                  <span className={styles.suggestionSkeleton} style={{ width: 140 }} />
                </div>
              )}
              {!!aiSuggestions.data?.suggestions.length && (
                <div className={styles.suggestionsRow}>
                  {aiSuggestions.data.suggestions.map((suggestion) => (
                    <button
                      key={suggestion.id}
                      type="button"
                      className={styles.suggestionChip}
                      onClick={() => setDraft(suggestion.text)}
                    >
                      <span className={styles.suggestionLabel}>{suggestion.tone}</span>
                      {suggestion.text}
                    </button>
                  ))}
                </div>
              )}
              <div className={styles.inputRow}>
                <button className={styles.suggestBtn} type="button" onClick={handleSuggest} aria-label="Suggest replies">
                  <Sparkles size={18} />
                </button>
                <textarea
                  className={styles.messageInput}
                  rows={1}
                  placeholder={`Message ${activeUser.name}`}
                  value={draft}
                  onChange={(event) => setDraft(event.target.value)}
                  onKeyDown={handleKeyDown}
                />
                <button
                  className={styles.sendBtn}
                  type="button"
                  onClick={handleSend}
                  disabled={!draft.trim() || sendMessage.isPending}
                  aria-label="Send message"
                >
                  <Send size={18} />
                </button>
              </div>
            </footer>
          </>
        )}
      </main>
    </div>
  );
}
