# Relay — API Contract Reference

This file is the handoff document between the frontend (built by Antigravity)
and the backend (built by you). It lists every mock service function the
frontend calls, the real HTTP endpoint it's expected to map to, and the
request/response shapes — all referencing types defined in
`src/types/types.ts`.

Antigravity: generate `src/types/types.ts` first, then make every mock
service in `src/api/services/` conform exactly to the shapes below.

---

## 1. Core Types (to live in `src/types/types.ts`)

```ts
export type PresenceStatus = 'online' | 'offline' | 'away';
export type MessageStatus = 'sent' | 'delivered' | 'read';

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl: string;
  status: PresenceStatus;
  lastSeen: string;        // ISO timestamp
  bio?: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  text: string;
  createdAt: string;       // ISO timestamp
  status: MessageStatus;
}

export interface Conversation {
  id: string;
  participantIds: string[];   // [currentUserId, otherUserId]
  lastMessage: Message | null;
  unreadCount: number;
  updatedAt: string;          // ISO timestamp, used for sidebar ordering
}

export interface TypingEvent {
  conversationId: string;
  userId: string;
  isTyping: boolean;
}

export interface AISuggestion {
  id: string;
  text: string;
  tone: 'formal' | 'casual' | 'concise' | 'friendly';
}

export interface AISuggestionRequest {
  draftText: string;
  conversationId: string;
}

export interface AISuggestionResponse {
  suggestions: AISuggestion[];
}

export interface AuthPayload {
  user: User;
  token: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface SignupRequest {
  name: string;
  email: string;
  password: string;
}

export interface AvatarUpdateRequest {
  userId: string;
  file: File; // multipart on real backend
}

export interface ApiError {
  message: string;
  code: string;
  statusCode: number;
}

export interface Paginated<T> {
  items: T[];
  nextCursor: string | null;
  hasMore: boolean;
}
```

---

## 2. Service → Endpoint Mapping

### authService.ts

| Function | Real Endpoint | Request | Response |
|---|---|---|---|
| `login(req: LoginRequest)` | `POST /api/auth/login` | `LoginRequest` | `AuthPayload` |
| `signup(req: SignupRequest)` | `POST /api/auth/signup` | `SignupRequest` | `AuthPayload` |
| `logout()` | `POST /api/auth/logout` | — | `204 No Content` |
| `getSession()` | `GET /api/auth/session` | — | `AuthPayload \| null` |

### userService.ts

| Function | Real Endpoint | Request | Response |
|---|---|---|---|
| `getUsers()` | `GET /api/users` | — | `User[]` |
| `getUserById(id)` | `GET /api/users/:id` | — | `User` |
| `updateProfile(id, partial)` | `PATCH /api/users/:id` | `Partial<User>` | `User` |
| `updateAvatar(req: AvatarUpdateRequest)` | `POST /api/users/:id/avatar` | multipart `file` | `{ avatarUrl: string }` |

### conversationService.ts

| Function | Real Endpoint | Request | Response |
|---|---|---|---|
| `getConversations()` | `GET /api/conversations` | — | `Conversation[]` (sorted by `updatedAt` desc) |
| `getConversationById(id)` | `GET /api/conversations/:id` | — | `Conversation` |

### messageService.ts

| Function | Real Endpoint | Request | Response |
|---|---|---|---|
| `getMessages(conversationId, cursor?)` | `GET /api/conversations/:id/messages` | query: `cursor?` | `Paginated<Message>` |
| `sendMessage(conversationId, text)` | `POST /api/conversations/:id/messages` | `{ text: string }` | `Message` |
| `markAsRead(conversationId)` | `POST /api/conversations/:id/read` | — | `204 No Content` |

### aiService.ts

| Function | Real Endpoint | Request | Response |
|---|---|---|---|
| `getSuggestions(req: AISuggestionRequest)` | `POST /api/ai/suggestions` | `AISuggestionRequest` | `AISuggestionResponse` |

### presenceService.ts / realtime (WebSocket, not REST)

These are mocked with `src/api/mockSocket.ts` on the frontend. On the real
backend these will likely be Socket.IO (or similar) events rather than REST
calls:

| Mock Function / Event | Real-world equivalent | Payload |
|---|---|---|
| `subscribeToPresence(callback)` | socket event `presence:update` | `{ userId: string, status: PresenceStatus }` |
| `subscribeToTyping(callback)` | socket event `typing:update` | `TypingEvent` |
| `subscribeToMessages(callback)` | socket event `message:new` | `Message` |
| `emitTyping(conversationId, isTyping)` | socket emit `typing` | `TypingEvent` |

The frontend's `mockSocket.ts` exposes `.on(event, cb)` / `.emit(event,
payload)` / `.connect()` / `.disconnect()` so swapping in a real
`socket.io-client` instance later should require touching only that one
file.

---

## 3. Notes for Backend Implementation

- All timestamps are ISO 8601 strings.
- `Conversation.unreadCount` should reset to 0 server-side when
  `markAsRead` is called for that conversation by the requesting user.
- Sidebar ordering on the frontend is driven purely by `updatedAt` — the
  backend should bump `updatedAt` on a conversation every time a new
  message is created in it.
- `AISuggestion.tone` values are just an example categorization the
  frontend mock uses to label the 2–3 suggestion bubbles; adjust freely as
  long as `AISuggestionResponse.suggestions` stays an array of
  `{ id, text, tone }`.
- Auth uses a simple bearer `token` in `AuthPayload` for now — frontend
  will store it (e.g. in memory / Zustand + localStorage) and you can swap
  in JWT/session-cookie auth as you see fit; just keep the `AuthPayload`
  response shape.
